<template>
	<view>
		<view class="h1">Wool 兼职平台</view>
		<view class="cont">纯朴的人们心中都有一个梦想，美美好好的，兼职就是人们通往梦想之路的一小段，兼职为梦想架一弯石桥，弓一样的小桥横跨两岸。美好的梦想时不时在兼职身后荡过，轻吟低唱，时不时露出舒心的笑容，引人走进。因而，我稚小的心灵，曾将心声献给占据了我们生活一小部分的兼职。那时你像是一弯银色的新月，给人们心里普照光辉；像是一把闪亮的镰刀，割刈着通往梦想路上的障碍；像是一根晃悠悠的扁担，挑起了我彩色的明天！哦，兼职走进我的生活中。</view>
		<view class="cont">心中的梦想，在心里像涌动的河水激荡起甜美的浪花，仰望一碧蓝天，心底轻声呼喊：梦想啊，我的梦想。为了实现一些小梦想，兼职是众多选择中的一个选择，兼职现在也成了我们生活当中的一小部分了。</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.h1{
		font-size: 32upx;
		text-align: center;
		font-weight: bold;
		line-height: 52px;
	}
.cont{
	font-size: 32upx;
	text-indent: 64upx;
	color: #666;
	text-justify:justify;
	text-align-last: left;
	padding: 0px 10px;
	padding-bottom: 30upx;
	box-sizing: border-box;
}
</style>
