<template>
	<view>
		<view class="jjbox">
			{{jj}}
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				jj:''
			}
		},
		onLoad(event){
			uni.setNavigationBarTitle({
				title: event.name+"简介"
			});
			this.jj=event.nr
		},
		methods: {
			
		}
	}
</script>

<style>
.jjbox{
	width: 94%;
	margin: 0upx auto;
	padding-top: 20upx;
	text-align: justify;
	text-align-last: left;
	font-size: 32upx;
	color: #666;
	text-indent: 64upx;
}
</style>
