<template>
	<view class="container animated fadeIn fast">
		<!-- #ifdef MP -->
		<view class="mp-search-box"><input class="ser-input" type="text" value="输入关键字搜索" disabled /></view>
		<!-- #endif -->
		<!-- 头部轮播 -->
		<view class="carousel-section">
			<!-- 标题栏和状态栏占位符 -->
			<view class="titleNview-placing"></view>
			<!-- 背景色区域 -->
			<view class="titleNview-background" :style="{backgroundColor:titleNViewBackground}"></view>
			<swiper class="carousel" circular @change="swiperChange" :autoplay="autoplay" :style="{backgroundColor:swiperBackground}">
				<swiper-item v-for="(item, index) in carouselList" :key="index" class="carousel-item" @click="navToDetailPage({title: '轮播广告'})">
					<image :src="item.src" />
				</swiper-item>
			</swiper>
			<!-- 自定义swiper指示器 -->
			<view class="swiper-dots">
				<text class="num">{{swiperCurrent+1}}</text>
				<text class="sign">/</text>
				<text class="num">{{swiperLength}}</text>
			</view>
		</view>
		<view class="seckill-section m-t" >
			<scroll-view class="floor-list" scroll-x>
				<view class="scoll-wrapper">
					<block v-for="(item, index) in goodsList" :key="index" >
						<view class="floor-item" @click="navToDetailPage(item.id)">
							<image :src="item.avatar" mode="aspectFill"></image>
							<view class="title clamp">{{item.name}}</view>
							<view class="price"><text>{{item.type}}</text></view>
							<view class="sums">+{{item.price}}</view>
						</view>
					</block>
				</view>
			</scroll-view>
		</view>
	    <view class="seckill-section m-t" >
			<view class="bxmain">
				<view class="ts1 jbtp">全部任务</view>
				<view class="ts2 bxbox">
					<swiper-tab-head :tabBars="tabBars" :tabIndex="tabIndex" @tabtap="tabtap"></swiper-tab-head>
				</view>
			</view>
		</view>
		<view class="content animated fadeIn fast">
			<view class="search-con">
				<view class="search-list">
					<block v-for="(value,key) in listData" :key="key">
					<view class="search-nr" @tap="ondoctTap(value.id)">
						<view class="avatarbox">
							<image :src="value.avatar" mode="aspectFill"></image>
						</view>
						<view class="search-nrxx">
							<view class="u-f u-f-jsb">
								<view class="xmtitle">
									<text class="telis">{{value.name}}</text>
								</view>
								<view class="zxbtn">+{{value.price}}</view>
							</view>
							<view class="">
								<view class="yytp u-f">
									<text style="font-size: 10px;color: #a1a1a1;background: #f0f0f0;padding: 1px 4px;border-radius: 2px;">{{value.type}}</text>
									<text style="margin-left: 10px; font-size: 10px; color: #a1a1a1; background: #f0f0f0; padding: 2px 4px; border-radius: 2px;">ID:{{value.id}}</text>
								</view>
								<view class="yybox u-f u-f-jsb">
									<text>剩余{{value.sumsy}}个</text><text>{{value.sumed}}人已赚</text>
								</view>
							</view>
						</view>
					</view>
					</block>
				</view>
			</view>
			<uni-load-more :status="status" :content-text="contentText" />
		</view>
	</view>
</template>

<script>
import swiperTabHead from "components/user/swiper-tab-heads.vue";
import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
var yzyTime = require('../../common/util.js').yzyTime;
export default {
	components: {
		swiperTabHead,
		uniLoadMore
	},
	data() {
		return {
			//导航
			swiperheight: 500,
			tabIndex: 0,
			tabBars: [{
					name: "默认排序",
					id: "all"
				},
				{
					name: "最新发布",
					id: "dzf"
				},
				{
					name: "佣金最高",
					id: "yzf"
				}
			],
			// 任务内容
			listData: [],
			reload: true,
			last_id: 0,
			status: 'more',
			contentText: {
				contentdown: '上拉加载更多',
				contentrefresh: '加载中',
				contentnomore: '没有更多'
			},
			
			titleNViewBackground: '',
			swiperBackground:'#ffffff',
			swiperCurrent: 0,
			autoplay: true, //自动播放
			interval: 1000, //自动切换时间
			duration: 500, //播放间隔
			swiperLength: 0,
			carouselList: [],
			goodsList: [],
			yiyuanList:[],
			imgUrl:this.config.imgUrl
		};
	},

	onLoad() {
		//this.ongrzlTap();
		
	},
	onShow() {
		this.getList();
		this.ongrzlTap();
	},
	onReachBottom() {
		this.status = 'more';
		this.getList();
	},
	methods: {
		// tabbar点击事件
		tabtap(index) {
			this.tabIndex = index
			this.listData=[];
			this.status = 'more';
			this.last_id=0;
			this.getList();
		},
		getList() {
			let data = {
				//column: 'id,post_id,title,author_name,cover,published_at' //需要的字段名
			};
			var limit=10;
			if (this.last_id>0) {
				//说明已有数据，目前处于上拉加载
				this.status = 'loading';
				data.offset = this.last_id*limit;
				data._ = new Date().getTime() + '';
			}
			data.limit=limit
			data.tabIndex=this.tabIndex			
			uni.request({
				url: this.config.webUrl+'/api/index/lists',
				data: data,
				success: data => {
					//console.log(data.data)
					if (data.data.total>0) {
						let list = data.data.rows;
						this.listData = this.reload ? list : this.listData.concat(list);
						this.reload = false;
						this.last_id = this.last_id+1;
						if(data.data.total<this.last_id*limit){
							this.status = '';
						}
					}
				},
				fail: (data, code) => {
				}
			});
		},
		setTimes(items){
			var newItems = [];
			items.forEach(e => {
				var str=e.headimgurl;
				if(str.indexOf("http") != -1){
					var urls=e.headimgurl;
				}else{
					var urls=this.config.imgUrl+e.headimgurl;
				}
				newItems.push({
					nickname: e.nickname,
					avatar:urls,
					id: e.id,
					titles: e.titles,
					yyname:e.yyname,
					department:e.department,
					seeksum:'+29.50',
					bio:e.techang
				});
			});
			return newItems;
		},
		ondoctTap(id){
			uni.navigateTo({
				url: `/pages/doctor/doctor?id=${id}`
			})
		},
		
		scan() {
			uni.scanCode({
				// onlyFromCamera: true,
				success: (res) => {
					console.log(res.result)
				}
			});
		
		},
		onYslistTap(){
			uni.navigateTo({
				url: '/pages/doctor_list/doctor_list',
			});
		},
		onYylistTap(){
			uni.navigateTo({
				url: '/pages/hospital_list/hospital_list',
			});
		},
		async ongrzlTap(){
			let _this=this;
			let [err,res] = await this.$http.get('/api/index/index',{});
			if (!this.$http.errorCheck(err,res)) return;
			//console.log(res.data)
			if(res.data.code === 1){
			 //this.listgrzl=res.data.data
			 this.loadData(res.data.data)
			 uni.setStorage({//缓存配置信息
			 	key: 'config',  
			 	data: res.data.data.config
			 })
			}else{
				this.$api.msg(res.data.msg);
				this.logining = false;
			}
		},
		goDetail(e) {  //跳转详情页面
			let detail = {
				author: e.author,
				avatar: e.img,
				yyname: e.yyname,
				id: e.id,
				updatetime: e.updatetime,
				title: e.title,
				htmlString:e.htmlString,
			};
			uni.navigateTo({
				url: '/pages/template/list2detail-detail/list2detail-detail?detailDate=' + encodeURIComponent(JSON.stringify(detail))
			});
		},
		/**
		 * 请求静态数据只是为了代码不那么乱
		 * 分次请求未作整合
		 */
		async loadData(data) {
			//console.log(data)
			/* 首页轮播图 */
			const carouselLists = data.config.banner;

			/* 医院列表 */
			const yiyuanLists = data.hospital;
			let carouselList = carouselLists;
			this.titleNViewBackground = carouselList[0].background;
			this.swiperLength = carouselList.length;
			this.carouselList = carouselList;

			// 医院医生
			this.goodsList = data.doctor|| [];
		},
		setTime(items) {
			var newItems = [];
			items.forEach(e => {
				var str=e.avatar;
				if(str.indexOf("http") != -1){
					var urls=e.img;
				}else{
					var urls=this.config.imgUrl+e.img;
				}
				newItems.push({
					author: e.author,
					img: urls,
					id: e.id,
					yyname: e.yyname,
					updatetime:yzyTime(e.updatetime),
					title: e.title,
					htmlString:e.info,
				});
			});
			return newItems;
		},
		//轮播图切换修改背景色
		swiperChange(e) {
			const index = e.detail.current;
			this.swiperCurrent = index;
			this.titleNViewBackground = this.carouselList[index].background;
		},
		//详情页
		navToDetailPage(id) {
			uni.navigateTo({
				url: `/pages/doctor/doctor?id=${id}`
			})
		},
		onyyTap(){
			uni.navigateTo({
				url: '../hospital/hospital',
			});
		},
		onindexTap(url){
			uni.navigateTo({
				url:url
			});
		}
	},
	// #ifndef MP
	// 标题栏input搜索框点击
	onNavigationBarSearchInputClicked: async function(e) {
		uni.navigateTo({
			url: '../search/search',
		});
	},
	//点击导航栏 buttons 时触发
	onNavigationBarButtonTap(e) {
		const index = e.index;
		console.log(index)
		if (index === 0) {
			//跳转扫一扫功能
			this.scan();
		} else if (index === 1) {
			// #ifdef APP-PLUS
			const pages = getCurrentPages();
			const page = pages[pages.length - 1];
			const currentWebview = page.$getAppWebview();
			currentWebview.hideTitleNViewButtonRedDot({
				index
			});
			//this.addr();
			// #endif
		}
	}
	// #endif
};
</script>

<style lang="scss">
	.telis{
		height: 22px;
	}
	.yybox{
		color: #666;
	}
	.yytp{
		color: #999;
	}
	.searchsc{
		margin-top: 5px;
		color: #999;
		font-size: 28upx;
		padding-left: 90px;
		box-sizing: border-box;
		text-align:justify;
		text-align-last: left;
		overflow:hidden; 
		text-overflow:ellipsis;
		display:-webkit-box; 
		-webkit-box-orient:vertical;
		-webkit-line-clamp:3; 
	}
	.search-con{
		padding:0upx 20upx;
		box-sizing: border-box;
	}
	.search-jcrs{
		color: #999;
	}
	.search-jcrs text{
		font-size: 28upx;
		font-weight: bold;
		color: #d1632d;
	}
	.zxbtn{
		color: #F17503;
		font-size: 32upx;
		height: 46upx;
		font-weight: 500;
		line-height: 46upx;
		border-radius: 28upx;
	}
	.search-nr{
		width: 100%;
		min-height: 88px;
		padding: 20upx;
		margin: 20upx auto;
		border-radius: 16upx;
		-webkit-box-shadow: 0 0 20px rgba(0, 0, 0, 0.08);
		box-shadow: 0 0 20px rgba(0, 0, 0, 0.08);
		margin: 20upx auto;
		background: #fafafa;
		position: relative;
		overflow: hidden;
	}
	.avatarbox{
		position: absolute;
		top: 32upx;
		left: 16upx;
		width:130upx;
		height: 130upx;
		border-radius: 16upx;
		overflow: hidden;
	}
	.avatarbox image{
		width: 130upx;
		height: 130upx;
		border-radius: 16upx;
	}
	.search-nrxx>view{
		padding-left: 140upx;
	}
	.xmtitle text:last-child{
		color: #999;
		font-size: 24upx;
	}
	.xmtitle text:first-child{
		color: #666;
		font-size: 30upx;
		padding-right: 10upx;
		font-weight: bold;
		line-height: 20px;
	}
	.satl-img{
		position: absolute;
		top:140upx;
		left:140upx;
		width: 28upx;
		height: 28upx;
		
	}
	
	.swiper-tab-list{
		font-size: 28upx!important;
		font-weight: normal!important;
	}
	.bxmain{
		-webkit-justify-content: space-around;
		justify-content: space-around;
		-webkit-align-content: center;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
	}
	.bxmain .ts1{
		flex:1;
	}
	.bxmain .ts2{
		flex:3;
	}
	.jbtp{
		font-size: 36upx;
		font-weight: bold;
		color: #3a3a3a;
	}
	.bxbox{
		    display: -webkit-box;
		    display: -webkit-flex;
		    display: flex;
		    -webkit-justify-content: space-around;
		    justify-content: space-around;
		    -webkit-align-content: center;
		    align-content: center;
		    background: #fff;
	}
/* #ifdef MP */
.mp-search-box {
	position: absolute;
	left: 0;
	top: 30upx;
	z-index: 9999;
	width: 100%;
	padding: 0 80upx;
	.ser-input {
		flex: 1;
		height: 56upx;
		line-height: 56upx;
		text-align: center;
		font-size: 28upx;
		color: $font-color-base;
		border-radius: 20px;
		background: rgba(255, 255, 255, 0.6);
	}
}

page {
	.cate-section {
		position: relative;
		z-index: 5;
		border-radius: 16upx 16upx 0 0;
		margin-top: -20upx;
	}
	.carousel-section {
		padding: 0;
		.titleNview-placing {
			padding-top: 0;
			height: 0;
		}
		.carousel {
			.carousel-item {
				padding: 0;
			}
		}
		.swiper-dots {
			left: 45upx;
			bottom: 40upx;
		}
	}
}
/* #endif */

page {
	background: #f9f9f9;
}
.m-t {
	margin-top: 16upx;
}
/* 头部 轮播图 */
.carousel-section {
	position: relative;
	padding-top: 10px;

	.titleNview-placing {
		height: var(--status-bar-height);
		padding-top: 44px;
		box-sizing: content-box;
	}

	.titleNview-background {
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 240upx;
		transition: 0.4s;
	}
}
.carousel {
	width: 100%;
	height: 200upx;

	.carousel-item {
		width: 100%;
		height: 100%;
		padding: 0 28upx;
		overflow: hidden;
	}

	image {
		width: 100%;
		height: 100%;
		border-radius: 10upx;
	}
}
.swiper-dots {
	display: flex;
	position: absolute;
	left: 60upx;
	bottom: 15upx;
	width: 72upx;
	height: 36upx;
	background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAABkCAYAAADDhn8LAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTMyIDc5LjE1OTI4NCwgMjAxNi8wNC8xOS0xMzoxMzo0MCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6OTk4MzlBNjE0NjU1MTFFOUExNjRFQ0I3RTQ0NEExQjMiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6OTk4MzlBNjA0NjU1MTFFOUExNjRFQ0I3RTQ0NEExQjMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6Q0E3RUNERkE0NjExMTFFOTg5NzI4MTM2Rjg0OUQwOEUiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6Q0E3RUNERkI0NjExMTFFOTg5NzI4MTM2Rjg0OUQwOEUiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4Gh5BPAAACTUlEQVR42uzcQW7jQAwFUdN306l1uWwNww5kqdsmm6/2MwtVCp8CosQtP9vg/2+/gY+DRAMBgqnjIp2PaCxCLLldpPARRIiFj1yBbMV+cHZh9PURRLQNhY8kgWyL/WDtwujjI8hoE8rKLqb5CDJaRMJHokC6yKgSCR9JAukmokIknCQJpLOIrJFwMsBJELFcKHwM9BFkLBMKFxNcBCHlQ+FhoocgpVwwnv0Xn30QBJGMC0QcaBVJiAMiec/dcwKuL4j1QMsVCXFAJE4s4NQA3K/8Y6DzO4g40P7UcmIBJxbEesCKWBDg8wWxHrAiFgT4fEGsB/CwIhYE+AeBAAdPLOcV8HRmWRDAiQVcO7GcV8CLM8uCAE4sQCDAlHcQ7x+ABQEEAggEEAggEEAggEAAgQACASAQQCCAQACBAAIBBAIIBBAIIBBAIABe4e9iAe/xd7EAJxYgEGDeO4j3EODp/cOCAE4sYMyJ5cwCHs4rCwI4sYBxJ5YzC84rCwKcXxArAuthQYDzC2JF0H49LAhwYUGsCFqvx5EF2T07dMaJBetx4cRyaqFtHJ8EIhK0i8OJBQxcECuCVutxJhCRoE0cZwMRyRcFefa/ffZBVPogePihhyCnbBhcfMFFEFM+DD4m+ghSlgmDkwlOgpAl4+BkkJMgZdk4+EgaSCcpVX7bmY9kgXQQU+1TgE0c+QJZUUz1b2T4SBbIKmJW+3iMj2SBVBWz+leVfCQLpIqYbp8b85EskIxyfIOfK5Sf+wiCRJEsllQ+oqEkQfBxmD8BBgA5hVjXyrBNUQAAAABJRU5ErkJggg==);
	background-size: 100% 100%;

	.num {
		width: 36upx;
		height: 36upx;
		border-radius: 50px;
		font-size: 24upx;
		color: #fff;
		text-align: center;
		line-height: 36upx;
	}

	.sign {
		position: absolute;
		top: 0;
		left: 50%;
		line-height: 36upx;
		font-size: 12upx;
		color: #fff;
		transform: translateX(-50%);
	}
}
/* 分类 */
.cate-section {
	display: flex;
	justify-content: space-around;
	align-items: center;
	flex-wrap: wrap;
	padding: 30upx 22upx;
	background: #fff;
	.cate-item {
		display: flex;
		flex-direction: column;
		align-items: center;
		font-size: $font-sm + 2upx;
		color: $font-color-dark;
	}
	/* 原图标颜色太深,不想改图了,所以加了透明度 */
	image {
		width: 100upx;
		height: 100upx;
		margin-bottom: 14upx;
		border-radius: 50%;
		opacity: 0.9;
		box-shadow: 4upx 4upx 20upx rgba(250, 67, 106, 0.3);
	}
}
.ad-1 {
	width: 100%;
	height: 210upx;
	padding: 10upx 0;
	background: #fff;
	image {
		width: 100%;
		height: 100%;
	}
}
/* 秒杀专区 */
.seckill-section {
	padding:10upx 30upx;
	background: #fff;
	.s-header {
		display: flex;
		align-items: center;
		height: 92upx;
		line-height: 1;
		.s-img {
			width: 140upx;
			height: 30upx;
		}
		.tip {
			font-size: $font-base;
			color: $font-color-light;
			margin: 0 20upx 0 10upx;
			font-size: 24upx;
		}
		.timer {
			display: inline-block;
			width: 40upx;
			height: 36upx;
			text-align: center;
			line-height: 36upx;
			margin-right: 14upx;
			font-size: $font-sm + 2upx;
			color: #fff;
			border-radius: 2px;
			background: rgba(0, 0, 0, 0.8);
		}
		.icon-you {
			font-size: $font-lg;
			color: $font-color-light;
			flex: 1;
			text-align: right;
		}
	}
	.floor-list {
		white-space: nowrap;
	}
	.scoll-wrapper {
		display: flex;
		align-items: flex-start;
		padding: 20upx 0upx;
	}
	.floor-item {
		width: 120px;
		margin-right: 10upx;
		margin-left: 10upx;
		font-size: $font-sm + 2upx;
		color: $font-color-dark;
		text-align: center;
		border-radius: 10upx;
		padding: 20upx 20upx;
		-webkit-box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
		box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
		image {
			width: 120upx;
			height: 120upx;
			border-radius: 10upx;
		}
		.clamp{
			text-align: center;
			font-size: 32upx;
			width: 100px;
			color: #333;
		}
		.price {
			color: #666;
			font-size: 20upx;
			line-height: 2;
			text-align: center;
		}
		.price text{
			font-size: 18upx;
			color: #a1a1a1;
			background: #f8f8f8;
			padding: 4upx 8upx;
			border-radius: 4upx;
		}
		.sums{
			color: #F17503;
			font-size: 32upx;
		}
	}
}

.f-header {
	display: flex;
	align-items: center;
	height: 140upx;
	padding: 6upx 30upx 8upx;
	background: #fff;
	image {
		flex-shrink: 0;
		width: 80upx;
		height: 80upx;
		margin-right: 20upx;
	}
	.tit-box {
		flex: 1;
		display: flex;
		flex-direction: column;
	}
	.tit {
		font-size: $font-lg + 2upx;
		color: #font-color-dark;
		line-height: 1.3;
	}
	.tit2 {
		font-size: $font-sm;
		color: $font-color-light;
	}
	.icon-you {
		font-size: $font-lg + 2upx;
		color: $font-color-light;
	}
}
/* 团购楼层 */
.group-section {
	background: #fff;
	.g-swiper {
		height: 650upx;
		padding-bottom: 30upx;
	}
	.g-swiper-item {
		width: 100%;
		padding: 0 30upx;
		display: flex;
	}
	image {
		width: 100%;
		height: 460upx;
		border-radius: 4px;
	}
	.g-item {
		display: flex;
		flex-direction: column;
		overflow: hidden;
	}
	.left {
		flex: 1.2;
		margin-right: 24upx;
		.t-box {
			padding-top: 20upx;
		}
	}
	.right {
		flex: 0.8;
		flex-direction: column-reverse;
		.t-box {
			padding-bottom: 20upx;
		}
	}
	.t-box {
		height: 160upx;
		font-size: $font-base + 2upx;
		color: $font-color-dark;
		line-height: 1.2;
	}
	.price {
		color: #666;
	}
	.m-price {
		font-size: $font-sm + 2upx;
		text-decoration: line-through;
		color: $font-color-light;
		margin-left: 8upx;
	}
	.pro-box {
		display: flex;
		align-items: center;
		margin-top: 10upx;
		font-size: $font-sm;
		color: $font-base;
		padding-right: 10upx;
	}
	.progress-box {
		flex: 1;
		border-radius: 10px;
		overflow: hidden;
		margin-right: 8upx;
	}
}
/* 猜你喜欢 */
.guess-section {
	display: flex;
	flex-wrap: wrap;
	padding: 0 30upx;
	background: #fff;
	.guess-item {
		display: flex;
		flex-direction: column;
		width: 48%;
		padding-bottom: 40upx;
		&:nth-child(2n + 1) {
			margin-right: 4%;
		}
	}
	.image-wrapper {
		width: 100%;
		height: 330upx;
		border-radius: 3px;
		overflow: hidden;
		image {
			width: 100%;
			height: 100%;
			opacity: 1;
		}
	}
	.title {
		font-size: $font-lg;
		color: $font-color-dark;
		line-height: 80upx;
	}
	.price {
		font-size: $font-lg;
		color: $uni-color-primary;
		line-height: 1;
	}
	.ffghg{
		font-size: 9px;color: #a1a1a1;background: #f8f8f8;padding: 2px 4px;border-radius: 2px;
	}
}
</style>
