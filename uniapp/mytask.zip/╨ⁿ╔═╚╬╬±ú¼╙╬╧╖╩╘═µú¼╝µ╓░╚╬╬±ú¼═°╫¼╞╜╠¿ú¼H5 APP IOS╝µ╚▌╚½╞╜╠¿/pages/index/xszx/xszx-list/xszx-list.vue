<template>
	<view>
		<view class="xfimgbox">
			<image src="/static/xhimg.jpg" mode="widthFix"></image>
		</view>
		<view class="xflist u-f">
			<view class="u-f1 u-f-ajc u-f-column" hover-class="avt" @tap="onlistTap('/pages/index/xszx/xszx-list/hyc/hyc')">
				<view class="iconfont iconxhimg1"></view>
				<text>欢迎辞</text>
			</view>
			<view class="u-f2">
				<view class="u-f1 u-f-ajc" hover-class="avt" @tap="onlistTap('/pages/index/xszx/xszx-list/zzjg/zzjg')">	<view class="iconfont iconxhimg2"></view>组织机构</view>
				<view class="u-f1 u-f-ajc" hover-class="avt" @tap="onlistTap('/pages/index/xszx/xszx-list/hyll/hyll')">	<view class="iconfont iconxhimg4"></view>参会浏览</view>
				<view class="u-f1 u-f-ajc" hover-class="avt" @tap="onlistTap('/pages/index/xszx/xszx-list/lxwm/lxwm')">	<view class="iconfont iconxhimg3"></view>联系我们</view>
			</view>
		</view>
		<view class="u-f urse">
			<view class="u-f1 u-f-ajc" hover-class="avt" @tap="onlistTap('/pages/index/xszx/xszx-list/reg/reg')">	<view class="iconfont iconxhimg5"></view>会员注册</view>
			<view class="u-f1 u-f-ajc" hover-class="avt">	<view class="iconfont iconxhimg"></view><text>会员管理</text></view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			onlistTap(url){
				uni.navigateTo({
					url: url
				});
			}
		}
	}
</script>

<style>
.xfimgbox image{
	width: 100%;
}
.avt{
	opacity: 0.8;
}
.iconfont{
	font-size: 38px;
	padding-right: 10upx;
}
.xflist>view:first-child{
	background: #d1632d;
	color: #fff;
	font-size: 32upx;
	margin-right: 5px;
}
.xflist>view:first-child .iconxhimg1{
	font-size: 48px;
	height: 66px;
}
.xflist>view:first-child text{
	position: relative;
}
.xflist>view:first-child text:after{
	position: absolute;
	content: '\e760';
	top: 0;
	left: 0;
	font-size: 48px;
	color: #fff;
}
.xflist>view:last-child> view{
	background: #f5f5f5;
}
.xflist .u-f2>view:nth-child(1){
	background: #e8dad3;
	color: #d1632d;
}
.xflist .u-f2>view:nth-child(2){
	background: #fafafa;
	color: #d1632d;
}
.xflist .u-f2>view:nth-child(3){
	background: #f0f0f0;
	color: #d1632d;
}
.urse>view{
	padding: 10upx 0upx;
	margin-top: 5px;
}
.urse>view:last-child{
	background: #d1632d;
	color: #fafafa;
	font-size: 32upx;
	margin-left: 5px;
}
.urse>view:first-child{
	background: #f0f0f0;
	color: #d1632d;
	font-size: 32upx;
}
</style>
