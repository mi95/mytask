<template>
	<view>
		<view class="conzzjg">
			<view class="zzjgh1">
				主办单位：
			</view>
			<view class="zzjgh">
				世界中医药学会联合会、世界针灸学会联合会、浙江省卫生和计划生育委员会。
			</view>
			<view class="zzjgh1">
				承办单位：
			</view>
			<view class="zzjgh">
				浙江中医药大学、世界中联科技发展委员会、世界中联真实世界研究专业委员会。
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.conzzjg{
		width: 94%;
		margin: 20upx auto;
	}
	.zzjgh1{
		color: #3a3a3a;
		font-size: 32upx;
		font-weight: bold;
		margin-top: 10upx;
	}
	.zzjgh{
		color: #666;
		font-size: 32upx;
		text-indent: 64upx;
		text-align: justify;
		text-align-last: left;
	}
</style>
