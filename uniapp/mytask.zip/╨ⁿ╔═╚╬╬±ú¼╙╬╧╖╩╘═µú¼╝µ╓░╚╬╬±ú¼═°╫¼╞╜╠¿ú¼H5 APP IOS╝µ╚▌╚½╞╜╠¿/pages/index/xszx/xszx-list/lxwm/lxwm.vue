<template>
	<view>
		<view class="conzzjg">
			<view class="uni-common-mt">
				<view>
					<map :latitude="latitude" :longitude="longitude" :markers="covers">
					</map>
				</view>
			</view>
			<view class="zzjgh1">
				大会联系人：
			</view>
			<view class="zzjgh">
				周亚男：18211065312
			</view>
			<view class="zzjgh">
				顾晓静：15801557833
			</view>
			<view class="zzjgh">
				陶有青：13522902130
			</view>
			<view class="zzjgh1">
				会议地址：
			</view>
			<view class="zzjgh">
				贵阳市南明区花果园中环广场2号写字楼31楼
			</view>
			<view class="zzjgh1">
				传真：
			</view>
			<view class="zzjgh">
				010-58650043
			</view>
			<view class="zzjgh1">
				邮箱：
			</view>
			<view class="zzjgh">
				zyzx973@126.com
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				latitude: 26.615799,
				longitude: 106.625909,
				covers: [{
					latitude: 26.615799,
					longitude: 106.625909,
					// #ifdef APP-PLUS
					iconPath: '/static/location@3x.png',
					// #endif
					// #ifndef APP-PLUS
					iconPath: '/static/location@3x.png',
					// #endif
				}]
			}
		},
		onLoad(){
			uni.getLocation({  
			                        type: 'wgs84',  
			                        success: function(res) {  
			                            this.distance='当前位置的经度：' + res.longitude+' 当前位置的纬度：' + res.latitude;  
			                            console.log('当前位置的经度：' + res.longitude);  
			                            console.log('当前位置的纬度：' + res.latitude);  
			                        },  
			                        fail:function(res){  
			                            console.log(res);  
			                        }  
			                    });  
		},
		methods: {

		}
	}
</script>

<style>
	map {
		width: 100%;
		height: 600upx;
	}
	.conzzjg{
		width: 94%;
		margin: 20upx auto;
	}
	.zzjgh1{
		color: #3a3a3a;
		font-size: 32upx;
		font-weight: bold;
		margin-top: 10upx;
	}
	.zzjgh{
		color: #666;
		font-size: 32upx;
		text-indent: 64upx;
		text-align: justify;
		text-align-last: left;
	}
</style>
