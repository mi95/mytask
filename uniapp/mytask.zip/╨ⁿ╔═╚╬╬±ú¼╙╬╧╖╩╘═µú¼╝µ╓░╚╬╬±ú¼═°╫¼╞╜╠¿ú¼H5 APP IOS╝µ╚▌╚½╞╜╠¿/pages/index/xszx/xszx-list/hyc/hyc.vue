<template>
	<view class="conhyc">
		<view class="hycnr">
			中医药蕴含着深厚的科学内涵，具有引领生命科学未来发展的巨大潜力。为更好地促进中医药传承创新，加强中医药领域国际科技合作，推动中医药在全世界的发展，世界中医药学会联合会定于2018年12月上旬在中国杭州召开首届世界中医药科技大会暨中医药国际贡献奖（科技进步奖）颁奖大会。同期召开世界中联科技发展委员会成立大会和真实世界研究专业委员会成立大会。
		</view>
		<view class="hycnr">
			本次大会将邀请来自中国、美国、德国、英国、法国、日本、澳大利亚、西班牙、中国香港、中国澳门等国家和地区的从事中医药相关研究的院士和著名专家学者做主题报告,同时邀请来自世界各国（地区）的中医药界和科技界的众多专家学者与会。大会除主会场外，还将设立中医研究、中药研究、针灸研究、真实世界研究、科技评价与成果转化、中医临床研究创新平台等6个分会场，就中医药最新科研成果、中医药研究方法学、中医药科技国际合作等进行学术交流，搭建中医药国际科技合作交流平台，共商中医药科技创新发展大业。
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.conhyc{
		width: 94%;
		margin: 0 auto;
	}
.hycnr{
	padding: 20upx 0;
	color: #666;
	font-size: 32upx;
	text-indent: 64upx;
	text-align: justify;
	text-align-last: left;
}
</style>
