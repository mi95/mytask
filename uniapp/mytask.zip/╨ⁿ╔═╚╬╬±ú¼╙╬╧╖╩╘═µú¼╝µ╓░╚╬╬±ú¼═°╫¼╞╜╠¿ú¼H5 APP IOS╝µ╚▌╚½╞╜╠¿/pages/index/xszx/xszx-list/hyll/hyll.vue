<template>
	<view class="yswcmain">
		<view class="yswcbox" @tap="onWcListTap()">
			<view class="yslist">
				<view class="yslist-title">中国医药包装协会第九届理事会第五次会议</view>
				<view class="yslist-time"><text>主办单位：贵州中医协会</text> <text>30分钟前</text></view>
			</view>
			<view class="yslist">
				<view class="yslist-title"> 你是肝癌易发人群吗？预防肝癌你一定要知道这些！</view>
				<view class="yslist-time"><text>主办单位：贵州中医协会</text> <text>两天前</text></view>
			</view>
			<view class="yslist">
				<view class="yslist-title">吃完9吨食物，一生就终结了？</view>
				<view class="yslist-time"><text>主办单位：贵州中医协会</text> <text>2019-07-31</text></view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
			onWcListTap(){
				uni.navigateTo({
					url: '/pages/index/xszx/xszx-list/hyll/hyllnr/hyllnr',
				})
			}
		}
	}
</script>

<style>
	.yswcmain {
		background: #fff;
	}

	.yswcbox {
		width: 94%;
		margin: 0 auto;
	}
	.yslist {
		padding: 16upx 0upx;
		border-bottom: 1upx solid #e5e5e5;
	}
	.yslist-title{
		font-size: 36upx;
		font-weight: 500;
		padding-left: 14upx;
		color: #666;
		text-align:justify;
		text-align-last: left;
		position: relative;
	}
	.yslist-title:after{
		position: absolute;
		content: '';
		top: 7px;
		left: 0px;
		width: 6upx;
		height:35upx;
		border-radius: 6upx;
		background: #F17503;
	}

	.yslist-time {
		font-size: 24upx;
		color: #999;
		justify-content: flex-end;
	}
	.yslist-time>text:first-child{
		padding-right: 16upx;
	}

	.doctortc>text {
		font-size: 28upx;
		color: #666;
		text-align: justify;
		text-align-last: left;

	}
</style>
