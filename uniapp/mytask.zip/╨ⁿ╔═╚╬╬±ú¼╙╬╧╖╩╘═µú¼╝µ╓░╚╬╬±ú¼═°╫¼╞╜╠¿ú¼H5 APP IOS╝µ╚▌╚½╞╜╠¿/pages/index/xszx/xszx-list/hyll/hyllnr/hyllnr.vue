<template>
	<view class="wcnrmian">
		<view class="titlebox">
			<text>关联审评审批政策沟通交流会</text>
		</view>
		<view class="ursexx">
			<view class="">
				发布时间：<text>2019-08-03</text>
			</view>
			<view class="">
				主办单位：<text>贵州中医协会</text>
			</view>
			<view class="">
				会议日期：<text>2019-08-26</text>
			</view>
		</view>
		<view class="wcnrbox">
			<image src="/static/mmtimg.jpg" mode="widthFix" lazy-load></image>
			<view class="title1">
				医药包装新产品新技术项目评选活动”自2019年开始举办，两年一次，得到了会员单位的大力支持，受到了相关政府部门的高度认可，很多获奖项目得到国家和地方政府的政策和资金支持
			</view>
			<view class="p1">
				随着注册制度改革的逐步深入，国家药品监督管理局于2019年4月4日发布了《关于进一步完善药品关联审评审批和监管工作有关事宜的公告（征求意见稿）》，就业界关注的药物制剂与原料药、药用辅料和药包材关联审评审批事宜进行了进一步明确,如药品制剂申请人或药品制剂生产企业（药品上市许可持有人）对于药品质量承担的主体责任问题、原辅包企业产品登记问题、变更供应商问题、监管部门信息如何使用和管理的问题以及药包材和药用辅料研究资料要求等等。
			</view>
			<view class="p1">
				  国家药品监督管理局现已完成意见征集和讨论，《公告》即将正式出台。为使行业企业更好地理解公告的内容和相关技术要求，我协会定于7月12日在青岛举办关联审评审批政策沟通交流会，邀请国家局药品注册司、监管司、药品审评中心等相关部门的领导专家对《公告》内容及相关技术要求进行指导，并就行业关心的问题进行交流。
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {

		}
	}
</script>

<style>
	.ursexx{
		padding: 30upx 0upx;
		font-weight: normal;
	}
	.ursexx>view>text{
		color: #666;
	}
	.wcnrbox{
		padding-bottom: 80upx;
	}
	.wcnrbox>image{
		display: block;
		width: 100%;
	}
	.title1{
		font-size: 32upx;
		font-weight: normal;
		color: #666;
		text-align: justify;
		text-align-last: left;
	}
	.p1{
		font-size: 32upx;
		text-indent: 64upx;
		text-align: justify;
		text-align-last: left;
		color: #666;
		font-weight: normal;
	}
	.wcnrmian {
		width: 94%;
		margin: 0 auto;
		font-weight: bold;
	}
	.avatarbox>text:nth-child(2){
		padding-left: 10upx;
		font-size: 32upx;
		color: #4651cd;
		padding-right: 10upx;
	}
	.avatarbox>text:nth-child(3){
		font-size: 28pux;
		color: #999;
		padding-right: 10upx;
		font-weight: normal;
	}
	.titlebox {
		font-size: 38upx;
		color: #3a3a3a;
		text-align:justify;
		text-align-last: left;
		border-bottom: 2px solid #FF4443;
	}
	.wctime{
		color: #999;
	}
</style>
