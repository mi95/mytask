<template>
	<view class="content">
		<text class="success-icon yticon icon-xuanzhong2"></text>
		<text class="tit">支付成功</text>
		
		<view class="btn-group">
			<navigator @tap="bak()" class="mix-btn">查看订单</navigator>
			<navigator url="/pages/index/index" open-type="switchTab" class="mix-btn hollow">返回首页</navigator>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			bak(){
				uni.navigateBack({
					delta:1,
				})
			}
		}
	}
</script>

<style lang='scss'>
	.content{
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}
	.success-icon{
		font-size: 160upx;
		color: #e17503;
		margin-top: 100upx;
		background-image: -webkit-gradient(linear, left top, left bottom, from(#ffac45), to(#F17503));
		background-image: -o-linear-gradient(top, #ffac45, #F17503);
		background-image: linear-gradient(to bottom, #ffac45, #F17503);
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
	}
	.tit{
		font-size: 38upx;
		color: #303133;
	}
	.btn-group{
		padding-top: 100upx;
	}
	.mix-btn {
		margin-top: 30upx;
		display: flex;
		align-items: center;
		justify-content: center;
		width: 600upx;
		height: 80upx;
		font-size: $font-lg;
		color: #fff;
		background: -webkit-linear-gradient(left, #f49315 , #f17503);
		background: -o-linear-gradient(right, #f49315, #f17503);
		background: -moz-linear-gradient(right, #f49315, #f17503);
		background: -webkit-gradient(linear, left top, right top, from(#f49315) , to(#f17503));
		background: -o-linear-gradient(left, #f49315 , #f17503);
		background: linear-gradient(to right, #f49315 , #f17503);
		border-radius: 10upx;
		&.hollow{
			background: #fff;
			color: #303133;
			border: 1px solid #ccc;
		}
	}
</style>
