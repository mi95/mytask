<template>
	<view>
		<view class="wdjfbox u-f u-f-ajc">
			<text>198.00</text>
		</view>
		<view class="yytbj">
			
		</view>
		<view class="jftitle u-f u-f-l">
			<text>到账明细</text>
		</view>
		<view class="uni-list">
		    <block v-for="(item,index) in lists" :key="index">
		        <view class="uni-list-cell" >
		            <view class="uni-triplex-row">
		                <view class="uni-triplex-left">
		                    <text class="uni-title uni-ellipsis">{{item.jftp}}</text>
		                    <text class="uni-text">{{item.jftime}}</text>
		                </view>
		                <view class="uni-triplex-right" style="width: 20%;">
		                   <text class="uni-h5">{{item.jflx}}{{item.jfprice}}</text>
		                </view>
		            </view>
		        </view>
		    </block>
		</view>
	</view>
</template>

<script>
	  export default {
	    data() {
	        return {
	            title: 'list-triplex-row',
	            lists: [
					{
						jftp:"到账明细",
						jftime:"2020-08-22",
						jfprice:"31.59",
						jflx:'+'
					},
					{
						jftp:"到账详细",
						jftime:"2020-08-22",
						jfprice:"15.20",
						jflx:'-'
					},
					{
						jftp:"到账详细",
						jftime:"2020-08-22",
						jfprice:"20.90",
						jflx:'+'
					},{
						jftp:"到账详细",
						jftime:"2020-08-30",
						jfprice:"15.26",
						jflx:'-'
					},
					{
						jftp:"到账详细",
						jftime:"2020-08-20",
						jfprice:"99.00",
						jflx:'+'
					},
					{
						jftp:"到账详细",
						jftime:"2019-07-21",
						jfprice:"12.50",
						jflx:'+'
					}
				]
	        }
	    },
		methods:{
			
		}
		
	}
</script>

<style>
	.yytbj{
		background: url(/static/jfimg.png);
		width: 100%;
		height: 6px;
		overflow: hidden;
	}
	.jftitle{
		line-height: 40px;
		padding-left: 30upx;
		font-size: 32upx;
	}
	.wdjfbox{
		background: rgba(255,0,0,0.05);
		border-top: 1upx solid #e5e5e5;
	}
	.wdjfbox text{
		line-height: 200upx;
		font-size: 58upx;
		font-weight: 500;
		letter-spacing: 2upx;
	}
	.uni-triplex-row{
		padding: 12upx 30upx;
	}
	.uni-title{
		color: #444;
		font-size: 32upx;
		font-weight: normal;
	}
	.uni-text{
		font-size: 24upx;
	}
	.uni-h5{
		font-size: 32upx;
		color: #3a3a3a;
		font-weight:500;
	}
</style>
