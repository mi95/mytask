<template>
	<view class="upbox">
		<view class="setlist">
			<view class="nrws u-f u-f-ac u-f-jsb">
				<view class="u-f1">投放单价 <text>*</text></view>
				<input class="u-f3" type="number" v-model="price"  placeholder="￥最低0.12元"  />
			</view>
			<view class="nrws u-f u-f-ac u-f-jsb">
				<view class="u-f1">投放数量 <text>*</text></view>
				<input class="u-f3" type="number" v-model="sum"  placeholder="最低20个"  />
			</view>
			<view class="nrwss u-f u-f-ac u-f-jsb">
				<view class="u-f1">结束时间 <text  class="ssie">*</text></view>
				<view class="u-f3">
					<picker mode="date" :value="date" :start="startDate" :end="endDate" @change="bindDateChange">
						<view>{{date}}<text class="cell-more yticon icon-you"></text></view>
					</picker>
				</view>
			</view>
			<view class="nrwss u-f u-f-ac u-f-jsb">
				<view class="u-f1">提交限时 <text class="ssie">*</text></view>
				<view class="u-f3">
					<picker @change="bindPickerChange" :value="index" :range="array" range-key="name">
						<view>{{array[index].name}}<text class="cell-more yticon icon-you"></text></view>
					</picker>
					
				</view>
			</view>
			<view class="nrwss u-f u-f-ac u-f-jsb">
				<view class="u-f1">审核周期 <text  class="ssie">*</text></view>
				<view class="u-f3"><picker @change="bindPickerChangezj" :value="zjindex" :range="zjay" range-key="name">
						<view>{{zjay[zjindex].name}}<text class="cell-more yticon icon-you"></text></view>
					</picker></view>
			</view>
			<view class="nrwss u-f u-f-ac u-f-jsb">
				<view class="u-f1">支付方式 <text  class="ssie">*</text></view>
				<view class="u-f3"><picker @change="bindPickerChangepay" :value="zjindex" :range="payarr" range-key="name">
						<view>{{payarr[payindex].name}}<text class="cell-more yticon icon-you"></text></view>
					</picker></view>
			</view>
		</view>
		<view class="upOnbox u-f u-f-ac u-f-jsb">
			<view class="yuise u-f2">总计：<text class="sungs">￥{{price*sum}}</text></view>
			<view class="upOnTaps u-f1" @tap="okTap()" >提交订单</view>
		</view>
	</view>
</template>

<script>
	function getDate(type) {
		const date = new Date();
	
		let year = date.getFullYear();
		let month = date.getMonth() + 1;
		let day = date.getDate();
	
		if (type === 'start') {
			year = year - 60;
		} else if (type === 'end') {
			year = year + 2;
		}
		month = month > 9 ? month : '0' + month;;
		day = day > 9 ? day : '0' + day;
	
		return `${year}-${month}-${day}`;
	}
export default {
		data() {
			return {
				title: 'picker',
				array: [{name:'请选择'},{name:'2小时'},{name: '3小时'}],
				index: 0,
			    zjay: [{name:'请选择'},{name:'24小时'},{name: '48小时'},{name: '72小时'}],
				zjindex: 0,
				payarr: [{name:'支付宝'},{name: '余额'}],
				payindex: 0,
				multiIndex: [0, 0, 0],
				date: '数量完成自动结束',
				startDate:getDate('start'),
				endDate:getDate('end'),
				price:'',
				sum:'',
				dataList:[],
				zprice:0,
			}
		},	
		onLoad(e) {
			this.dataList=uni.getStorageSync("rwdata")
		},
		methods: {
			bindPickerChange: function(e) {
				console.log('picker发送选择改变，携带值为：' + e.detail.value)
				this.index = e.detail.value
			},
			bindPickerChangezj: function(e) {
				console.log('picker发送选择改变，携带值为：' + e.detail.value)
				this.zjindex = e.detail.value
			},
			bindDateChange: function(e) {
				this.date = e.detail.value
			},
			bindPickerChangepay: function(e) {
				console.log('picker发送选择改变，携带值为：' + e.detail.value)
				this.payindex = e.detail.value
			},
			okTap(){
				var thia=this
				if(!this.price){
					this.$api.msg('投放单价不能为空');
					return;
				}
				if(!this.sum){
					this.$api.msg('投放数量不能为空');
					return;
				}
				if(this.array[this.index].name=='请选择'){
					this.$api.msg('提交时间不能为空');
					return;
				}
				if(this.zjay[this.zjindex].name=='请选择'){
					this.$api.msg('审核周期不能为空');
					return;
				}
				if(this.payarr[this.payindex].name=='请选择支付方式'){
					this.$api.msg('请选择支付方式');
					return;
				}
				this.dataList.price=this.price;
				this.dataList.sum=this.sum;
				this.dataList.endtime=this.date,
				this.dataList.subtime=this.array[this.index].name;
				this.dataList.shetime=this.zjay[this.zjindex].name;
				this.dataList.buytype=this.payarr[this.payindex].name;
				//https://rw.gzzsw.cn/api/pay/index?token=a69720a4-6c4c-4baf-b269-d5260b821c7a
				let data = this.dataList;
				data.token = uni.getStorageSync("userInfo").token;
				data.uid = uni.getStorageSync("userInfo").id;
				data.buzs = JSON.stringify(data.buz); 
				//console.log(data)
				uni.request({
					url: this.config.webUrl+'/api/pay/index',
					data: data,
					success: resa =>{
						console.log(resa.data);
						if(thia.dataList.buytype=='支付宝'){
							thia.okPay(resa)
						}else if(thia.dataList.buytype=='余额'){
							if(resa.data.code==1){
								//pages/user/task/task
								uni.showModal({
									title: '提示',
									content: resa.data.msg,
									showCancel: false,
									success: res => {
										uni.navigateBack({
											delta:2,
										})
									}
								});
							}else{
								this.$api.msg(resa.data.msg);
							}
						}
						//thia.okPay(resa)
					},
					fail: (data, code) => {
						console.log('fail' + JSON.stringify(data));
					}
				});
				
				
			},
			okPay(orderInfo){
				console.log(orderInfo);
				uni.requestPayment({
				    provider: 'alipay',
				    orderInfo: orderInfo.data, //微信、支付宝订单数据
				    success: function (res) {
						uni.showModal({
							title: '提示',
							content: '发布成功',
							showCancel: false,
							success: res => {
								uni.navigateBack({
									delta:2,
								})
							}
						});
				        //console.log('success:' + JSON.stringify(res));
				    },
				    fail: function (err) {
						this.$api.msg(JSON.stringify(err));
				        //console.log('fail:' + JSON.stringify(err));
				    }
				});
			}
		}	
}		
</script>

<style>
	page{
		background: #f3f3f3;
	}
	.yuise{
		text-align: center;
	}
	.upbox{
		background: #fff;
	}
	.sungs{
		color: #FF4443;
		font-size: 36upx;
		font-weight: 500;
	}
	.setlist{
		width: 94%;
		margin: 0 auto;
	}
	.nrws{
		padding: 26upx 0;
		border-bottom: 2upx solid #E4E7ED;
	}
	.nrws input{
		font-size: 30upx;
		text-align: right;
	}
	.nrws view:nth-child(1){
		font-size: 32upx;
		color: #111;
		width: 80px;
	}
	.nrws view:nth-child(2){
		text-align: right;
	}
	.nrws view:nth-child(1) text{
		color: #FF3333;
	}
	.setlist .nrws:last-child{
		border-bottom: none;
	}
	
	.nrwss{
		padding: 26upx 0;
		border-bottom: 2upx solid #E4E7ED;
	}
	.nrwss view:nth-child(1){
		font-size: 32upx;
		color: #111;
	}
	.nrwss view:nth-child(2){
		text-align: right;
	}
	.ssie{
		color: #FF3333;
	}
	.upOnbox{
		width: 100%;
		background: #fff;
		position: fixed;
		left: 0;
		right: 0;
		bottom: 0;
		padding: 20upx 40upx;
		box-sizing: border-box;
	}
	.upOnTaps{
		width: 60%;
		margin: 0 auto;
		height: 80upx;
		line-height: 80upx;
		text-align: center;
		background: #FFB400;
		color: #000;
		border-radius: 60px;
		font-size: 32upx;
	}
</style>
