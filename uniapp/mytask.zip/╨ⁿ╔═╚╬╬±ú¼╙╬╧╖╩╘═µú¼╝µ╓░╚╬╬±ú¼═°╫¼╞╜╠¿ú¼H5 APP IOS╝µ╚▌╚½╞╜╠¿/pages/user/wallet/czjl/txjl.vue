<template>
	<view>
		<view class="uni-list">
		    <block v-for="(item,index) in listData" :key="index">
		        <view class="uni-list-cell" hover-class="uni-list-cell-hover">
		            <view class="uni-triplex-row">
		                <view class="uni-triplex-left">
		                    <text class="uni-title uni-ellipsis">{{item.createtime}} {{item.name}}</text>
		                    <text class="uni-text">帐号：{{item.cord}}</text>
							<text class="uni-text">手续费：{{item.sxf}}</text>
							<text class="uni-text" style="font-size: 20upx; color: #ff0000;" v-if="item.memoj">备注：{{item.memoj}}</text>
		                </view>
		                <view class="uni-triplex-right" style="width: 25%;">
							<text class="uni-h5">{{item.type}}</text>
		                   <text class="uni-h5" style="font-size: 24upx; color: #ff0000;">￥{{item.money}}</text>
						   <text class="uni-h5" v-if="item.iscl==1">未审核</text>
						   <text class="uni-h5" v-if="item.iscl==2">已审核</text>
						   <text class="uni-h5" v-if="item.iscl==3">已拒绝</text>
		                </view>
		            </view>
		        </view>
		    </block>
		</view>
		<uni-load-more :status="status" :content-text="contentText" />
	</view>
</template>

<script>
	var yzyTime = require('../../../../common/util.js').yzyTime;
	import uniLoadMore from '@/components/uni-load-more/uni-load-more.vue';
	  export default {
		  components: {
		  	uniLoadMore
		  },
	    data() {
	        return {
	            listData: [],
				last_id: 0,
				reload: true,
				status: 'more',
				contentText: {
					contentdown: '上拉加载更多',
					contentrefresh: '加载中',
					contentnomore: '没有更多'
				}
	        }
	    },
	    onReachBottom() {
	    	this.status = 'more';
	    	this.getList();
	    },
	    onLoad() {
	    	this.getList();
	    },
		methods: {
			getList() {
				let data = {
					//column: 'id,post_id,title,author_name,cover,published_at' //需要的字段名
				};
				var limit=10;
				if (this.last_id>0) {
					//说明已有数据，目前处于上拉加载
					this.status = 'loading';
					data.offset = this.last_id*limit;
					data._ = new Date().getTime() + '';
				}
				data.limit=limit		
				data.token = uni.getStorageSync("userInfo").token;
				uni.request({
					url: this.config.webUrl+'/api/user/txinfo',
					data: data,
					success: data => {
						console.log(data.data)
						if (data.data.total>0) {
							let list = data.data.rows;
							this.listData = this.reload ? list : this.listData.concat(list);
							this.reload = false;
							this.last_id = this.last_id+1;
							if(data.data.total<this.last_id*limit){
								this.status = '';
							}
						}
					},
					fail: (data, code) => {
						//console.log('fail' + JSON.stringify(data));
					}
				});
			},
		}
	}
</script>

<style>
	.uni-title{
		color: #444;
		font-size: 32upx;
		font-weight: normal;
	}
	.uni-text{
		font-size: 28upx;
	}
	.uni-h5{
		font-size: 32upx;
		color: #3a3a3a;
		font-weight:500;
	}
</style>
