<template>
	<view >
		<view class="u-f u-f-ajc" style="position: absolute;top: -180px;left: 0;right: 0;bottom: 0;">
			<view class="walletmain">
				<view class="u-f u-f-ajc u-f-column">
					<view class="iconfont iconfinancial_fill"></view>
					<view class="wallnum">我的余额</view>
					<view class="">{{money}}</view>
				</view>
				<view class="wall-btn">
					<button type="primary" @tap="onZcTap()" >提现</button>	
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				money:''
			}
		},
		onShow(){
			this.ongrzlTap()
		},
		methods: {
			async ongrzlTap(){
				let _this=this;
				let [err,res] = await this.$http.get('/api/user/index',{},{token:true});
				if (!this.$http.errorCheck(err,res)) return;
				if(res.data.code === 1){
					this.money=res.data.data.money;
				}else{
					this.$api.msg(res.data.msg);
					this.logining = false;
				}
			},
			onZcTap(){
				uni.navigateTo({
					url:'/pages/user/wallet/cz/tx',
					animationType: 'slide-in-bottom'
				})
			},
			// 监听原生标题导航按钮点击事件
			onNavigationBarButtonTap(e) {
				const index = e.index;
					uni.navigateTo({
						url:"/pages/user/wallet/czjl/czjl"
					})
					
			}
		}
	}
</script>

<style>
.iconfinancial_fill{
	font-size: 89px;
	color: #F17503;
	height: 120px;
	background-image: -webkit-gradient(linear, left top, left bottom, from(#ffac45), to(#F17503));
    background-image: -o-linear-gradient(top, #ffac45, #F17503);
    background-image: linear-gradient(to bottom, #ffac45, #F17503);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.wallnum{
	font-size: 28upx;
	color: #3a3a3a;
}
.walletmain{
	width: 70%;
}
.walletmain>view>view:last-child{
	font-size: 42px;
	font-weight: bold;
	position: relative;
	display: flex;
	padding-left: 40upx;
	letter-spacing: 2upx;
}
.walletmain>view>view:last-child:after{
	position: absolute;
	top: 10px;
	left: 0px;
	content: '￥';
	font-size: 48upx;
	font-weight: bold;
}
.wall-btn{
	width: 100%;
}
.wall-btn button{
	width: 100%;
	margin: 30px auto;
	display: block;
	border: none!important;
	background: -webkit-linear-gradient(left, #f49315 , #f17503); /* Safari 5.1 - 6.0 */
	background: -o-linear-gradient(right, #f49315, #f17503); /* Opera 11.1 - 12.0 */
	background: -moz-linear-gradient(right, #f49315, #f17503); /* Firefox 3.6 - 15 */
	background: linear-gradient(to right, #f49315 , #f17503); /* 标准的语法（必须放在最后） */
}
</style>
