<template>
	<view class="container animated fadeIn fast">
		<view class="user-section">
			<image class="bg" :src="userInfo.portrait || '/static/user-bg.jpg'"></image>
			<view class="user-info-box" @click="navTo('/pages/set/grzl/grzl')">
				<view class="portrait-box"><image class="portrait" :src="userInfo.portrait || '/static/missing-face.png'"></image></view>
				<view class="info-box">
					<text class="username">{{ userInfo.nickname || '游客' }}</text>
				</view>
			</view>
			<view class="vip-card-box">
				<image class="card-bg" src="/static/vip-card-bg.png" mode=""></image>
				<view class="b-btn" @click="navTo('/pages/set/grzl/grzl')">实名认证</view>
				<view class="tit">
					<text class="yticon icon-iLinkapp-"></text>
					wool实名认证
				</view>
				<text class="e-m">小巧、好用的APP</text>
				<text class="e-b">简单任务轻松做 也可以发布任务 </text>
			</view>
		</view>

		<view
			class="cover-container"
			:style="[
				{
					transform: coverTransform,
					transition: coverTransition
				}
			]"
			@touchstart="coverTouchstart"
			@touchmove="coverTouchmove"
			@touchend="coverTouchend"
		>
			<image class="arc" src="/static/arc.png"></image>

			<view class="tj-sction hslo">
				<view class="tj-item" @click="navTo('/pages/user/wallet/wallet')">
					<text class="num">{{urerdata.money?urerdata.money:'0'}}</text>
					<text>当前余额</text>
				</view>
				<!-- <view class="tj-item" @click="navTo('/pages/user/jifen/jifen')">
					<text class="num">{{urerdata.voucher?urerdata.voucher:'0'}}</text>
					<text>今日到账</text>
				</view> -->
	<!-- 			<view class="tj-item" @click="navTo('/pages/user/wallet/cz/cz')">
					<text class="txbnt">提现</text>
				</view> -->
				<view class="tj-item" @click="navTo('/pages/user/wallet/cz/cz')">
					<text class="txbnt">充值</text>
				</view>
			</view>
			<!-- 订单 -->
			<view class="">
				<view class="list-cell wdboxs" @click="navTo('/pages/user/orderrw/order?stype=0')">
					<text class="cell-tit telse">我的任务</text>
					<text class="cell-tip">查看全部</text>
					<text class="cell-more yticon icon-you"></text>
				</view>
			<view class="order-section">
				<view class="order-item" @click="navTo('/pages/user/orderrw/order?stype=1')" hover-class="common-hover" :hover-stay-time="50">
					<text class="iconfont wdicon iconzhengzaijinhang"></text>
					<text>待提交</text>
				</view>
				<view class="order-item" @click="navTo('/pages/user/orderrw/order?stype=2')" hover-class="common-hover" :hover-stay-time="50">
					<text class="iconfont wdicon iconbijiben"></text>
					<text>审核中</text>
				</view>
				<view class="order-item" @click="navTo('/pages/user/orderrw/order?stype=3')" hover-class="common-hover" :hover-stay-time="50">
					<text class="iconfont wdicon iconwendangtijiao"></text>
					<text>已通过</text>
				</view>
				<view class="order-item" @click="navTo('/pages/user/orderrw/order?stype=4')" hover-class="common-hover" :hover-stay-time="50">
					<text class="iconfont wdicon iconzhangdan"></text>
					<text>未通过</text>
				</view>
				<view class="order-item" @click="navTo('/pages/user/orderrw/order?stype=5')" hover-class="common-hover" :hover-stay-time="50">
					<text class="iconfont wdicon iconbianji1"></text>
					<text>复审举报</text>
				</view>
			</view>
			</view>
			<view class="history-section icon" >
				<view class="list-cell m-t" @click="navTo('/pages/user/task/task')">
					<text class="cell-icon yticon icon-dizhi" style="color: rgb(224, 116, 114);"></text>
					<text class="cell-tit">发布/管理任务</text>
					<text class="cell-tip cose">免费发布</text>
					<text class="cell-more yticon icon-you"></text>
				</view>
				<view class="list-cell b-b" @click="navTotg('/pages/order/order')">
					<text class="cell-icon yticon icon-iconfontweixin" style="color: #ee883b;"></text>
					<text class="cell-tit">邀友赚钱</text>
					<text class="cell-tip ">躺着收钱</text>
					<text class="cell-more yticon icon-you"></text>
				</view>
				<view class="list-cell b-b" @click="navTo('/pages/template/list2detail-list/list2detail-list')">
					<text class="cell-icon yticon icon-shoucang_xuanzhongzhuangtai" style="color: #9789f7;"></text>
					<text class="cell-tit">帮助中心</text>
					<text class="cell-tip "></text>
					<text class="cell-more yticon icon-you"></text>
				</view>
				<view class="list-cell b-b" @click="navTotel()" >
					<text class="cell-icon yticon icon-share" style="color: #5fcda2;"></text>
					<text class="cell-tit">联系客服</text>
					<text class="cell-tip "></text>
					<text class="cell-more yticon icon-you"></text>
				</view>
				<view class="list-cell b-b" @click="navTo('/pages/set/set')">
					<text class="cell-icon yticon icon-shezhi1" style="color:#e07472;"></text>
					<text class="cell-tit">设置</text>
					<text class="cell-tip "></text>
					<text class="cell-more yticon icon-you"></text>
				</view>
			</view>
		</view>
	</view>
</template>
<script>
import {mapMutations} from 'vuex';//方法跳转 mapMutations
import listCell from '@/components/mix-list-cell';
import {mapState} from 'vuex';//请求数据 mapState
let startY = 0,
	moveY = 0,
	pageAtTop = true;
export default {
	components: {
		listCell
	},
	data() {
		return {
			coverTransform: 'translateY(0px)',
			coverTransition: '0s',
			moving: false,
			imgUrl:'',
			urerdata:[]
		};
	},
	
	onLoad() {
	 
	},
	onShow(){
		if (this.hasLogin) {
			this.ongrzlTap();
		}
	},
	// #ifndef MP
	onNavigationBarButtonTap(e) {
		const index = e.index;
		
		console.log(index)
		if (index === 0) {
			this.navTo('/pages/set/set');
		} else if (index === 1) {
			// #ifdef APP-PLUS
			const pages = getCurrentPages();
			const page = pages[pages.length - 1];
			const currentWebview = page.$getAppWebview();
			currentWebview.hideTitleNViewButtonRedDot({
				index
			});
			// #endif
			uni.navigateTo({
				url: '/pages/notice/notice'
			});
		}
	},
	// #endif
	computed: {
		...mapState(['hasLogin', 'userInfo'])//第一个值判断是否登录，第二个是用登录成功用户基本信息
	},
	methods: {
		...mapMutations(['navigate']),
		/**
		 * 统一跳转接口,拦截未登录路由
		 * navigator标签现在默认没有转场动画，所以用view
		 */
		async ongrzlTap(){
			let data = {};
			data.token = uni.getStorageSync("userInfo").token;
			data.uid = uni.getStorageSync("userInfo").id;
			uni.request({
				url: this.config.webUrl+'/api/user/index',
				data: data,
				success: res =>{
					if(res.data.code==1){
						this.urerdata=res.data.data
						
					}else{
						this.$api.msg(res.data.msg);
						this.logining = false;
					}
				},
				fail: (data, code) => {
					//console.log('fail' + JSON.stringify(data));
				}
			});		
		},
		navTotel(){
			uni.makePhoneCall({
			    phoneNumber: uni.getStorageSync("config").tels //仅为示例 
			});
		},
		navTo(url) {
			if (!this.hasLogin) {
				url = '/pages/public/login';
			}
			uni.navigateTo({
				url
			});
		},
		navTotg(url) {
			if (!this.hasLogin) {
				url = '/pages/public/login';
			}
			uni.switchTab({
				url
			});
		},
		onUserTap(url){
			uni.navigateTo({
				url: url
			});
		},
		/**
		 *  会员卡下拉和回弹
		 *  1.关闭bounce避免ios端下拉冲突
		 *  2.由于touchmove事件的缺陷（以前做小程序就遇到，比如20跳到40，h5反而好很多），下拉的时候会有掉帧的感觉
		 *    transition设置0.1秒延迟，让css来过渡这段空窗期
		 *  3.回弹效果可修改曲线值来调整效果，推荐一个好用的bezier生成工具 http://cubic-bezier.com/
		 */
		coverTouchstart(e) {
			if (pageAtTop === false) {
				return;
			}
			this.coverTransition = 'transform .1s linear';
			startY = e.touches[0].clientY;
		},
		coverTouchmove(e) {
			moveY = e.touches[0].clientY;
			let moveDistance = moveY - startY;
			if (moveDistance < 0) {
				this.moving = false;
				return;
			}
			this.moving = true;
			if (moveDistance >= 80 && moveDistance < 100) {
				moveDistance = 80;
			}

			if (moveDistance > 0 && moveDistance <= 80) {
				this.coverTransform = `translateY(${moveDistance}px)`;
			}
		},
		coverTouchend() {
			if (this.moving === false) {
				return;
			}
			this.moving = false;
			this.coverTransition = 'transform 0.3s cubic-bezier(.21,1.93,.53,.64)';
			this.coverTransform = 'translateY(0px)';
		}
	}
};
</script>
<style lang="scss">
	.list-cell{
		display:flex;
		align-items:baseline;
		padding: 20upx $page-row-spacing;
		line-height:60upx;
		position:relative;
		background: #fff;
		justify-content: center;
		&.log-out-btn{
			margin-top: 40upx;
			.cell-tit{
				color: $uni-color-primary;
				text-align: center;
				margin-right: 0;
			}
		}
		&.cell-hover{
			background:#fafafa;
		}
		&.b-b:after{
			left: 30upx;
		}
		&.m-t{
			margin-top: 16upx; 
		}
		.cell-more{
			align-self: baseline;
			font-size:$font-lg;
			color:$font-color-light;
			margin-left:10upx;
		}
		.cell-tit{
			flex: 1;
			font-size: $font-base + 2upx;
			color: $font-color-dark;
			margin-right:10upx;
		}
		.cell-tip{
			font-size: $font-base;
			color: $font-color-light;
		}
		switch{
			transform: translateX(16upx) scale(.84);
		}
	}
	.cell-icon{
		-webkit-align-self: center;
		-ms-flex-item-align: center;
		align-self: center; 
		width: 56upx;
		max-height: 60upx;
		font-size: 38upx;
	}
	.cose{
		color: #F17503!important;
	}
%flex-center {
	display: flex;
	flex-direction: column;
	justify-content: center;
	align-items: center;
}
%section {
	display: flex;
	justify-content: space-around;
	align-content: center;
	background: #fff;
	border-radius: 10upx;
}
.txbnt{
	background: #fff;
	color: #111;
	padding: 4upx 50upx;
	border-radius: 50upx;
	font-size: 28upx;
	font-weight: 500;
}
.hslo{
	background: #FFB400;
}
.icon-iconfontweixin{
	font-size: 17px!important;
	padding-left: 4upx;
}
.wdboxs{
	width: 100%;
	background: #fff;
	margin-top: 20upx;
	border-top-left-radius:10upx;
	border-top-right-radius:10upx;
}
.wdboxs:active{
	background: #f9f9f9!important;
}
.telse{
	font-size: 32upx!important;
	font-weight: bold;
}
.user-section {
	height: 520upx;
	padding: 100upx 30upx 0;
	position: relative;
	.bg {
		position: absolute;
		left: 0;
		top: 0;
		width: 100%;
		height: 100%;
		filter: blur(30px);
		opacity: 0.5;
	}
}
.user-info-box {
	height: 180upx;
	display: flex;
	align-items: center;
	position: relative;
	z-index: 1;
	.portrait {
		width: 130upx;
		height: 130upx;
		border: 5upx solid #fff;
		border-radius: 50%;
	}
	.username {
		font-size: $font-lg + 6upx;
		color: $font-color-dark;
		margin-left: 20upx;
	}
}

.vip-card-box {
	display: flex;
	flex-direction: column;
	color: #f7d680;
	height: 240upx;
	background: linear-gradient(left, rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.8));
	border-radius: 16upx 16upx 0 0;
	overflow: hidden;
	position: relative;
	padding: 20upx 24upx;
	.card-bg {
		position: absolute;
		top: 20upx;
		right: 0;
		width: 380upx;
		height: 260upx;
	}
	.b-btn {
		position: absolute;
		right: 20upx;
		top: 16upx;
		width: 132upx;
		height: 40upx;
		text-align: center;
		line-height: 40upx;
		font-size: 22upx;
		color: #36343c;
		border-radius: 20px;
		background: linear-gradient(left, #f9e6af, #ffd465);
		z-index: 1;
	}
	.tit {
		font-size: $font-base + 2upx;
		color: #f7d680;
		margin-bottom: 28upx;
		.yticon {
			color: #f6e5a3;
			margin-right: 16upx;
		}
	}
	.e-b {
		font-size: $font-sm;
		color: #d8cba9;
		margin-top: 10upx;
	}
}
.cover-container {
	background: $page-color-base;
	margin-top: -150upx;
	padding: 0 30upx;
	position: relative;
	background: #f5f5f5;
	padding-bottom: 20upx;
	.arc {
		position: absolute;
		left: 0;
		top: -34upx;
		width: 100%;
		height: 36upx;
	}
}
.tj-sction {
	@extend %section;
	.tj-item {
		@extend %flex-center;
		flex-direction: column;
		height: 140upx;
		font-size: $font-sm;
		color: #111;
	}
	.num {
		font-size: 40upx;
		color: #fff;
		margin-bottom: 8upx;
	}
}
.order-section {
	@extend %section;
	padding: 16upx 0;
	padding-top: 0upx;
	margin-top: 0upx;
	border-top-left-radius:0upx;
	border-top-right-radius:0upx;
	.order-item {
		@extend %flex-center;
		width: 120upx;
		height: 120upx;
		border-radius: 10upx;
		font-size: $font-sm;
		color: $font-color-dark;
	}
	.yticon {
		font-size: 48upx;
		margin-bottom: 18upx;
		color: #fa436a;
	}
	.wdicon {
		height: 30px;
		line-height: 30px;
		font-size: 52upx;
		color: #de5909;
		background-image: linear-gradient(to bottom, #ffac45, #FFB400);
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
	}
	.icon-shouhoutuikuan {
		font-size: 44upx;
	}
}
.history-section {
	padding: 0upx 0 0;
	margin-top: 20upx;
	background: #fff;
	border-radius: 10upx;
	.sec-header {
		display: flex;
		align-items: center;
		font-size: $font-base;
		color: $font-color-dark;
		line-height: 40upx;
		margin-left: 30upx;
		.yticon {
			font-size: 44upx;
			color: #5eba8f;
			margin-right: 16upx;
			line-height: 40upx;
		}
	}
	.h-list {
		white-space: nowrap;
		padding: 30upx 30upx 0;
		image {
			display: inline-block;
			width: 160upx;
			height: 160upx;
			margin-right: 20upx;
			border-radius: 10upx;
		}
	}
}
</style>