<template>
	<view class="content animated fadeIn fast">
		<view class="search-con">
			<view class="search-list">
				<view class="search-nr">
					<view class="avatarbox">
						<image src="../../../static/tximg.jpg" mode="aspectFill"></image>
					</view>
					<view class="search-nrxx">
						<view class="u-f u-f-jsb">
							<view class="xmtitle">
								<text>阳光少年</text><text></text>
							</view>
							<view class="zxbtn">ID：W520221</view>
						</view>
						<view class="">
							<view class="yybox">
								<text>2020-08-30 TA邀请我来到Wool平台</text>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>
<script>

</script>

<style>
page {
	display: flex;
	flex-direction: column;
	box-sizing: border-box;
	background-color: #fff;
}
.search-main{
	width: 100%;
	border-bottom: 20upx solid #f5f6f6;
}
.hzyh-main{
	width: 100%;
	padding-top: 30upx;
	border-top: 8px solid #f5f6f6;
}
.hzyh-box{
	width: 92%;
	margin: 0 auto;
}
.hzyh-box-title text:nth-child(1){
	font-size: 36upx;
	font-weight: bold;
	padding-right: 10upx;
}
.hzyh-box-title text:nth-child(2){
	color: #999;
}
.zys-ssjl {
	margin-top: 30upx;
	margin-bottom: 30upx;
	color: #3a3a3a;
	padding: 10upx 0upx;
}
.yybox text{
	font-size: 24upx;
	color: #666;
}
.zys-ssjl text{
	padding: 4upx 18upx;
	color: #666;
	border-radius: 40upx;
	border: 2upx solid #e5e5e5;
	margin-right: 6upx;
	font-size: 28upx;
}
.search-box {
	width: 92%;
	margin: 20upx auto;
}
.search-box input {
	height: 34px;
	line-height: 34px;
	background: #f5f6f6;
	color: #999;
	border-radius: 20px;
	padding-left: 40px;
	font-size: 28upx;
}
.searchg{
	position: relative;
	word-break: keep-all;
	white-space: pre;
	position: relative;
}
.searchg .iconsousuo{
	position: absolute;
	left: 30upx;
	top: 15upx;
	font-size: 36upx;
	color: #666;
	font-weight: 500;
}
.zys-jbtp {
	line-height: 50px;
	font-size: 36upx;
	font-weight: bold;
	color: #3a3a3a;
}
.example {
	padding: 0 30upx 30upx;
}

.example-title {
	font-size: 32upx;
	line-height: 32upx;
	color: #777;
	margin: 40upx 25upx;
	position: relative;
}

.example .example-title {
	margin: 40upx 0;
}

.example-body {
	padding: 0 40upx;
}
.searchsc{
	margin-top: 5px;
	color: #999;
	font-size: 28upx;
	padding-left: 90px;
	box-sizing: border-box;
	text-align:justify;
	text-align-last: left;
	overflow:hidden; 
	text-overflow:ellipsis;
	display:-webkit-box; 
	-webkit-box-orient:vertical;
	-webkit-line-clamp:3; 
}
.search-con{
	padding:0upx 20upx;
	box-sizing: border-box;
}
.search-jcrs{
	color: #999;
}
.search-jcrs text{
	font-size: 28upx;
	font-weight: bold;
	color: #d1632d;
}
.zxbtn{
	color: #666;
	font-size: 24upx;
	height: 46upx;
	line-height: 46upx;
	border-radius: 28upx;
}
.search-nr{
	width: 100%;
	min-height: 80px;
	padding: 20upx;
	margin: 20upx auto;
	border-radius: 16upx;
	-webkit-box-shadow: 0 0 20px rgba(0, 0, 0, 0.08);
	box-shadow: 0 0 20px rgba(0, 0, 0, 0.08);
	margin: 20upx auto;
	background: #fff;
	position: relative;
	overflow: hidden;
}
.avatarbox{
	position: absolute;
	top: 25upx;
	left: 20upx;
	width:100upx;
	height: 100upx;
	border-radius: 50%;
	overflow: hidden;
}
.avatarbox image{
	width: 100upx;
	height: 100upx;
	border-radius: 50%;
}
.search-nrxx{
	padding-top: 10upx;
}
.search-nrxx>view{
	padding-left: 130upx;
}
</style>
