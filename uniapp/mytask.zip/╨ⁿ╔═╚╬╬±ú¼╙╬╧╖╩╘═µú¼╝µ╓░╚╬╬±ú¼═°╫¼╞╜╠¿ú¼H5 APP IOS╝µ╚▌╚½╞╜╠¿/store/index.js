import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const store = new Vuex.Store({
	state: {
		hasLogin: false,
		userInfo: {},
	},
	mutations: {
		login(state, provider) {

			state.hasLogin = true;
			state.userInfo = provider;
			uni.setStorage({//缓存用户登陆状态
			    key: 'userInfo',  
			    data: provider  
			}) 
			//console.log(state.userInfo);
		},
		logout(state) {
			state.hasLogin = false;
			state.userInfo = {};
			uni.removeStorage({  
                key: 'userInfo'  
            })
			
		},
		// 权限验证跳转
		navigate(options,type = "navigateTo"){
			// 是否登录验证
			if (!this.hasLogin) {
				return uni.navigateTo({url:'/pages/public/login'});
			}
			// 跳转
			switch (type){
				case "navigateTo":
				uni.navigateTo(options);
					break;
				case "redirectTo":
				uni.redirectTo(options);
					break;
				case "reLaunch":
				uni.reLaunch(options);
					break;
				case "switchTab":
				uni.switchTab(options);
					break;
			}
		},
	},
	actions: {
	
	}
})

export default store
