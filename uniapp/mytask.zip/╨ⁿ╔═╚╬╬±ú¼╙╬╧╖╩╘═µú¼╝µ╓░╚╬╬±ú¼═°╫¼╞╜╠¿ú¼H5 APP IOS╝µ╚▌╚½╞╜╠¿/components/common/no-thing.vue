<template>
	<view class="nothing u-f-ajc">
		<image src="/static/nothing.png" mode="widthFix"></image>
	</view>
</template>

<script>
	
</script>

<style scoped>
	.nothing{
		background: #fff;
		position: absolute;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
	}
	.nothing image{
		width: 60%;
	}
</style>
