<template>
	<view class="uni-tab-bar">
		<scroll-view scroll-x class="uni-swiper-tab">
			<block v-for="(tab,index) in tabBars" :key="tab.id">
				<view class="swiper-tab-list" :class="{'active':tabIndex==index}" @tap="tabtap(index)">
					{{tab.name}}
					<view class="swiper-tab-line"></view>
				</view>
			</block>
		</scroll-view>
	</view>
</template>

<script>
	export default{
		props:{
			tabBars:Array,
			tabIndex:Number
		},
		methods:{
			// tabbar点击事件
			tabtap(index){
				// this.tabIndex=index
				this.$emit('tabtap',index)
				if(index==2){
					console.log(index)
					show('right')
				}
			}
		}
	}
</script>

<style>
	.uni-swiper-tab{
		height: 86upx;
		line-height: 60upx;
		padding-bottom: 20upx;
		background: #f5f5f5;
		border-bottom: none;
	}
	.swiper-tab-list{
		width: 33.3333%;
		color: #969696;
		font-weight: bold;
	}
	.uni-tab-bar .active{
		color: #343434;
	}
	.active .swiper-tab-line{
		border-bottom: 3upx solid #f49315;
		width: 70upx;
		margin: auto;
		border-top: 3upx solid #f49315;
		border-radius: 20upx;
		
	}
	
</style>
