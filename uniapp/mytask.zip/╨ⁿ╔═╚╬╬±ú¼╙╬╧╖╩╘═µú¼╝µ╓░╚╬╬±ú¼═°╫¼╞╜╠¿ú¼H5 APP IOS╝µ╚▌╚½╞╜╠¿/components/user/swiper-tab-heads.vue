<template>
	<view class="uni-tab-bar">
		<scroll-view scroll-x class="uni-swiper-tab u-f u-f-jsb">
			<block v-for="(tab,index) in tabBars" :key="tab.id" >
				<view class="swiper-tab-list" :class="{'active':tabIndex==index}" @tap="tabtap(index)">
					{{tab.name}}
					<view class="swiper-tab-line"></view>
				</view>
			</block>
			
		</scroll-view>
	</view>
</template>

<script>
	export default{
		props:{
			tabBars:Array,
			tabIndex:Number
		},
		methods:{
			// tabbar点击事件
			tabtap(index){
				// this.tabIndex=index
				// console.log(index)
				this.$emit('tabtap',index)
			}
		}
	}
</script>

<style>
	.uni-swiper-tab{
		background: #fff;
		height: 36px;
		line-height: 36px;
		border-bottom: 1upx solid rgba(0,0,0,.1)!important;
	}
	.swiper-tab-list{
		width:80px;
		color: #969696;
	}
	.uni-tab-bar .active{
		color: #343434;
	}
	.active .swiper-tab-line{
		border-bottom: 4upx solid #f49315;
		width: 70upx;
		margin: auto;
		border-top: 4upx solid #f49315;
		border-radius: 20upx;
		
	}
	
</style>
