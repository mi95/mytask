// 配置信息
export default {
	// api请求前缀
	webUrl:'http://127.0.0.1:8082',
	imgUrl:'http://127.0.0.1:8082',
	// webUrl:'https://rw.gzzsw.cn',//uni.getStorageSync("config").weburl?uni.getStorageSync("config").weburl:'http://192.168.10.175',
	// imgUrl:'https://rw.gzzsw.cn',//uni.getStorageSync("config").imgurl?uni.getStorageSync("config").imgurl:'http://192.168.10.175',
	// websocket地址
	//websocketUrl:"https://wx.gzyz1.com",
	// 消息提示tabbar索引  websocketUrl:"https://wx.gzyz1.com",
	TabbarIndex:2
}