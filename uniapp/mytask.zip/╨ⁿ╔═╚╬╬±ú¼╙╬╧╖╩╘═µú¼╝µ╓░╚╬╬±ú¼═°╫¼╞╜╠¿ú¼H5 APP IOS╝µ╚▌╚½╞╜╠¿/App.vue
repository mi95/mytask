<script>
	/**
	 * vuex管理登陆状态，具体可以参考官方登陆模板示例
	 */
	import {
		mapMutations
	} from 'vuex';
	export default {
		methods: {
			...mapMutations(['login'])
		},
		onLaunch: function() {
			// 网路监听（用户目前断网，切换wifi）
			this.lib.NetWork.On();
			let userInfo = uni.getStorageSync('userInfo') || '';
			if(userInfo.id){
				//更新登陆状态
				uni.getStorage({
					key: 'userInfo',
					success: (res) => {
						this.login(res.data);
					}
				});
			}
			//#ifdef APP-PLUS  
			//APP更新
			// 锁定屏幕方向
			var webUrl ="https://www.baiyaoyuansc.com";
			var imgUrl ="https://www.baiyaoyuansc.com";
			uni.request({
				url: webUrl+'/api/index/index',
				success: data => {
					
					if (data.data.code>0) {
						
						uni.setStorage({//缓存配置信息
							key: 'config',  
							data: data.data.data.config
						})
						
					}
				},
				fail: (data, code) => {
					
				}
			});
			plus.screen.lockOrientation('portrait-primary'); //锁定
			// 检测升级
			var yzyversion = plus.runtime.version //获取当前APP版本
			
			var config =  uni.getStorageSync('config');
			
			var appversion = config.appversion //版本号
			
			var bigupapp = config.bigupapp //是否更新0不更新1更新 大更新
			
			var upapp = config.upapp //是否更新0不更新1更新 小更新
			
			var androidbigupurl = config.androidbigupurl //安卓安装包
			
			var smallupurl = config.smallupurl //更新升级包
			
			var iosbigupurl = config.iosbigupurl //IOS 更新地址

			if(upapp==1){
				console.log("当前版本"+yzyversion)
				console.log("新版本"+appversion)
				if(yzyversion==appversion){
					
				}else{
					uni.showModal({
						title: '',
						content:"更新提示",
						showCancel: false,
						confirmText: "确定",
						success: function (res) {
							//plus.runtime.openURL(imgUrl+smallupurl);
							downWgt(imgUrl+smallupurl)
						}
					});
				}
			}
			if(bigupapp==1){
				let openUrl = plus.os.name === 'iOS' ? iosbigupurl : imgUrl+androidbigupurl;
				if(yzyversion*1==appversion*1){
					
				}else{
				uni.showModal({
					title: '',
					content:"更新提示",
					showCancel: false,
					confirmText: "确定",
					success: function (res) {
						plus.runtime.openURL(openUrl);
						uni.reLaunch({
							url:'/pages/public/login'
						})
					}
				});
				}	
			}		
			 //#endif
			 
			// 下载wgt文件  
			//var wgtUrl="http://demo.dcloud.net.cn/test/update/H5EF3C469.wgt";  
			function downWgt(wgtUrl){  
			plus.nativeUI.showWaiting("下载文件...");  
			plus.downloader.createDownload( wgtUrl, {filename:"_doc/update/"}, function(d,status){  
			    if ( status == 200 ) {   
			        console.log("下载成功："+d.filename);  
			        installWgt(d.filename); // 安装wgt包  
			    } else {  
			        console.log("下载失败！");  
			        plus.nativeUI.alert("下载失败！");  
			    }  
			    plus.nativeUI.closeWaiting();  
			}).start();  
			}  
			 
			// 更新应用资源  
			function installWgt(path){  
			plus.nativeUI.showWaiting("安装文件...");  
			plus.runtime.install(path,{},function(){  
			    plus.nativeUI.closeWaiting();  
			    console.log("安装文件成功！");  
			    plus.nativeUI.alert("应用资源更新完成！",function(){  
			        plus.runtime.restart();  
			    });  
			},function(e){  
			    plus.nativeUI.closeWaiting();  
			    console.log("安装文件失败["+e.code+"]："+e.message);  
			    plus.nativeUI.alert("安装文件失败["+e.code+"]："+e.message);  
			});  
			}   
			
			 
		},
		onShow: function() {
			//console.log('App Show')
		},
		onHide: function() {
			//console.log('App Hide')
		},
	}
</script>

<style lang='scss'>
   	/*每个页面公共css */
   /* uni.css - 通用组件、模板样式库，可以当作一套ui库应用 */
   @import './common/uni.css';
   /* 图标 */
   @import './common/iconfont.css';
   	/* 引入动画库 */
   @import './common/animate.css';
   /* 公共样式 */
    @import './common/common.css';
	@font-face {
		font-family: yticon;
		font-weight: normal;
		font-style: normal;
		src: url('static/yzy.ttf') format('truetype');

	}

	.yticon {
		font-family: "yticon" !important;
		font-size: 16px;
		font-style: normal;
		-webkit-font-smoothing: antialiased;
		-moz-osx-font-smoothing: grayscale;
	}

	.icon-yiguoqi1:before {
		content: "\e700";
	}

	.icon-iconfontshanchu1:before {
		content: "\e619";
	}

	.icon-iconfontweixin:before {
		content: "\e611";
	}

	.icon-alipay:before {
		content: "\e636";
	}

	.icon-shang:before {
		content: "\e624";
	}

	.icon-shouye:before {
		content: "\e626";
	}

	.icon-shanchu4:before {
		content: "\e622";
	}

	.icon-xiaoxi:before {
		content: "\e618";
	}

	.icon-jiantour-copy:before {
		content: "\e600";
	}

	.icon-fenxiang2:before {
		content: "\e61e";
	}

	.icon-pingjia:before {
		content: "\e67b";
	}

	.icon-daifukuan:before {
		content: "\e68f";
	}

	.icon-pinglun-copy:before{
		content: "\e612";
	}

	.icon-dianhua-copy:before {
		content: "\e621";
	}

	.icon-shoucang:before {
		content: "\e645";
	}

	.icon-xuanzhong2:before {
		content: "\e62f";
	}

	.icon-gouwuche_:before {
		content: "\e630";
	}

	.icon-icon-test:before {
		content: "\e60c";
	}

	.icon-icon-test1:before {
		content: "\e632";
	}

	.icon-bianji:before {
		content: "\e646";
	}

	.icon-jiazailoading-A:before {
		content: "\e8fc";
	}

	.icon-zuoshang:before {
		content: "\e613";
	}

	.icon-jia2:before {
		content: "\e60a";
	}

	.icon-huifu:before {
		content: "\e68b";
	}

	.icon-sousuo:before {
		content: "\e7ce";
	}

	.icon-arrow-fine-up:before {
		content: "\e601";
	}

	.icon-hot:before {
		content: "\e60e";
	}

	.icon-lishijilu:before {
		content: "\e6b9";
	}

	.icon-zhengxinchaxun-zhifubaoceping-:before {
		content: "\e616";
	}

	.icon-naozhong:before {
		content: "\e64a";
	}

	.icon-xiatubiao--copy:before {
		content: "\e608";
	}

	.icon-shoucang_xuanzhongzhuangtai:before {
		content: "\e6a9";
	}

	.icon-jia1:before {
		content: "\e61c";
	}

	.icon-bangzhu1:before {
		content: "\e63d";
	}

	.icon-arrow-left-bottom:before {
		content: "\e602";
	}

	.icon-arrow-right-bottom:before {
		content: "\e603";
	}

	.icon-arrow-left-top:before {
		content: "\e604";
	}

	.icon-icon--:before {
		content: "\e744";
	}

	.icon-zuojiantou-up:before {
		content: "\e605";
	}

	.icon-xia:before {
		content: "\e62d";
	}

	.icon--jianhao:before {
		content: "\e60b";
	}

	.icon-weixinzhifu:before {
		content: "\e61a";
	}

	.icon-comment:before {
		content: "\e64f";
	}

	.icon-weixin:before {
		content: "\e61f";
	}

	.icon-fenlei1:before {
		content: "\e620";
	}

	.icon-erjiye-yucunkuan:before {
		content: "\e623";
	}

	.icon-Group-:before {
		content: "\e688";
	}

	.icon-you:before {
		content: "\e606";
	}

	.icon-forward:before {
		content: "\e607";
	}

	.icon-tuijian:before {
		content: "\e610";
	}

	.icon-bangzhu:before {
		content: "\e679";
	}

	.icon-share:before {
		content: "\e656";
	}

	.icon-yiguoqi:before {
		content: "\e997";
	}

	.icon-shezhi1:before {
		content: "\e61d";
	}

	.icon-fork:before {
		content: "\e61b";
	}

	.icon-kafei:before {
		content: "\e66a";
	}

	.icon-iLinkapp-:before {
		content: "\e654";
	}

	.icon-saomiao:before {
		content: "\e60d";
	}

	.icon-shezhi:before {
		content: "\e60f";
	}

	.icon-shouhoutuikuan:before {
		content: "\e631";
	}

	.icon-gouwuche:before {
		content: "\e609";
	}

	.icon-dizhi:before {
		content: "\e614";
	}

	.icon-fenlei:before {
		content: "\e706";
	}

	.icon-xingxing:before {
		content: "\e70b";
	}

	.icon-tuandui:before {
		content: "\e633";
	}

	.icon-zuanshi:before {
		content: "\e615";
	}

	.icon-zuo:before {
		content: "\e63c";
	}

	.icon-shoucang2:before {
		content: "\e62e";
	}

	.icon-shouhuodizhi:before {
		content: "\e712";
	}

	.icon-yishouhuo:before {
		content: "\e71a";
	}

	.icon-dianzan-ash:before {
		content: "\e617";
	}





	view,
	scroll-view,
	swiper,
	swiper-item,
	cover-view,
	cover-image,
	icon,
	text,
	rich-text,
	progress,
	button,
	checkbox,
	form,
	input,
	label,
	radio,
	slider,
	switch,
	textarea,
	navigator,
	audio,
	camera,
	image,
	video {
		box-sizing: border-box;
	}
	/* 骨架屏替代方案 */
	.Skeleton {
		background: #f3f3f3;
		padding: 20upx 0;
		border-radius: 8upx;
	}

	/* 图片载入替代方案 */
	.image-wrapper {
		font-size: 0;
		background: #f3f3f3;
		border-radius: 4px;

		image {
			width: 100%;
			height: 100%;
			transition: .6s;

			&.loaded {
				
			}
		}
	}
	.clamp {
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		display: block;
	}
	.titlemp{
		height: 104upx!important;
		overflow:hidden!important;
		text-overflow:ellipsis!important;
		display:-webkit-box!important;
		-webkit-box-orient:vertical!important;
		-webkit-line-clamp:2!important;
	}
	.common-hover {
		background: #f5f5f5;
	}

	/*边框*/
	.b-b:after,
	.b-t:after {
		position: absolute;
		z-index: 3;
		left: 0;
		right: 0;
		height: 0;
		content: '';
		transform: scaleY(.5);
		border-bottom: 1px solid $border-color-base;
	}

	.b-b:after {
		bottom: 0;
	}

	.b-t:after {
		top: 0;
	}

	/* button样式改写 */
	uni-button,
	button {
		height: 80upx;
		line-height: 80upx;
		font-size: $font-lg + 2upx;
		font-weight: normal;

		&.no-border:before,
		&.no-border:after {
			border: 0;
		}
	}

	uni-button[type=default],
	button[type=default] {
		color: $font-color-dark;
	}

	/* input 样式 */
	.input-placeholder {
		color: #999999;
	}

	.placeholder {
		color: #999999;
	}
</style>
